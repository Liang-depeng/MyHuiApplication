package com.bh.ldp.myhuiapplication;

import com.bh.ldp.lib_base.basev.BaseView;

/**
 * created by Da Peng at 2019/10/12
 */
public class CaiPuContract {

    public interface View extends BaseView {

        void requsetData();

    }

    public interface Presenter {

    }

}
