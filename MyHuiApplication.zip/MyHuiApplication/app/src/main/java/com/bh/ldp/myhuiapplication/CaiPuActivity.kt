package com.bh.ldp.myhuiapplication

import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import com.bh.ldp.lib_base.basev.BaseActivity
import com.bh.ldp.lib_base.http.HttpHelper
import com.bh.ldp.lib_base.http.OnHttpResponseListner
import com.bh.ldp.lib_base.utils.LogUtils
import org.json.JSONObject

class CaiPuActivity : BaseActivity(), CaiPuContract.View, OnHttpResponseListner {

    private val httpHelper = HttpHelper(this)

    override fun requsetData() {
       // httpHelper.setGsonClass()
        httpHelper.startRequest("https://api.jisuapi.com/weather/query?appkey=3e4e0c080d3f1aa5&city=重庆")
    }

    override fun initPresenter() {
        val presenter = CaiPuPresenter(this)
    }

    override fun initView() {

    }

    override fun initData() {

    }

    override fun getLayoutResId(): Int {
        return R.layout.activity_cai_pu
    }

    override fun onSuccess(obj: Any) {
        if (obj is JSONObject){
            val string = (obj as JSONObject).toString()
            LogUtils.d(TAG,string)
        }
    }

    override fun onFailed(obj: Any) {
        showLongToast(obj.toString())
    }

}
