package com.bh.ldp.myhuiapplication;

import android.app.Application;

import com.bh.ldp.lib_base.BaseApplication;

/**
 * created by Da Peng at 2019/10/12
 */
public class MyApplication extends BaseApplication {

    @Override
    public void onCreate() {
        super.onCreate();
    }

}
