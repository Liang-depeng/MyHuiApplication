package com.bh.ldp.myhuiapplication;

import com.bh.ldp.lib_base.basev.BasePresenter;

/**
 * created by Da Peng at 2019/10/12
 */
public class CaiPuPresenter extends BasePresenter<CaiPuContract.View> implements CaiPuContract.Presenter{

    public CaiPuPresenter(CaiPuContract.View mView) {
        super(mView);
    }


}
