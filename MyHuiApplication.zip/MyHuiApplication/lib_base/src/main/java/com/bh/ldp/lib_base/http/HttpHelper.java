package com.bh.ldp.lib_base.http;

import com.google.gson.Gson;

import org.jetbrains.annotations.NotNull;
import org.json.JSONObject;

import java.io.IOException;

import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;

/**
 * created by Da Peng at 2019/10/12
 */
public class HttpHelper {

    private OnHttpResponseListner lisetener;
    private Class gsonClass = null;

    public HttpHelper(OnHttpResponseListner lisetener) {
        this.lisetener = lisetener;
    }

    public void setGsonClass(Class gsonClass) {
        this.gsonClass = gsonClass;
    }

    public void startRequest(String netUrl) {

        OkHttpClient okHttpClient = new OkHttpClient();
        Request request = new Request.Builder().url(netUrl).build();

        Call call = okHttpClient.newCall(request);
        call.enqueue(new Callback() {
            @Override
            public void onFailure(@NotNull Call call, @NotNull IOException e) {
                lisetener.onFailed("请求失败");
            }

            @Override
            public void onResponse(@NotNull Call call, @NotNull Response response) throws IOException {
                try {
                    String result = response.body().toString();
                    JSONObject jsonObject = new JSONObject(result);

                    if (gsonClass!=null){
                        Object object = new Gson().fromJson(jsonObject.toString(), gsonClass);
                        lisetener.onSuccess(object);
                    }else {
                        lisetener.onSuccess(jsonObject);
                    }

                } catch (Exception e) {
                    e.printStackTrace();
                }

            }
        });
    }
}
