package com.bh.ldp.lib_base.basev;

/**
 * created by Da Peng at 2019/6/21
 */
public abstract class BasePresenter<V extends BaseView> implements BasePresenterImpl {

    protected V mView = null;

    public BasePresenter(V mView) {
        this.mView = mView;
    }

    @Override
    public void onDetachView() {
        mView = null;
    }
}
