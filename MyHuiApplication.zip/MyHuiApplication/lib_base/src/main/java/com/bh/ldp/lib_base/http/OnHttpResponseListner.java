package com.bh.ldp.lib_base.http;

import org.json.JSONObject;

import androidx.annotation.NonNull;

/**
 * created by Da Peng at 2019/10/12
 */
public interface OnHttpResponseListner {

    void onSuccess(@NonNull Object obj);

    void onFailed(@NonNull Object obj);

}
