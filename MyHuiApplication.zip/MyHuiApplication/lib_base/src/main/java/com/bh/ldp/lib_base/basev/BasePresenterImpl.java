package com.bh.ldp.lib_base.basev;

/**
 * created by Da Peng at 2019/6/21
 */
public interface BasePresenterImpl {

    void onDetachView();

}
