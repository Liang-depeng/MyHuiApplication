package com.bh.ldp.lib_base.view;

/**
 * created by Da Peng at 2019/8/2
 */
public interface onRefreshListener {

    /**
     * @param refresh true 下拉， false上拉
     */
    void onRefresh(boolean refresh);

}
