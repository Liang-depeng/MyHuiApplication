package com.bh.ldp.lib_base.view;

/**
 * created by Da Peng at 2019
 */
public interface MultiLayoutType<T> {

    int getLayoutResType(T data, int position);

}
